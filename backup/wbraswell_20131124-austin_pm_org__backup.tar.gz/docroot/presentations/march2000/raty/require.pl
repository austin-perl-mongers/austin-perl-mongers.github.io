# Version number for require needs to be
# V string: either 5.6.0 or v5.6.0.
require 5.6.0; # or require v5.6.0

# Deprecated
require 5.005_03;

# Will choke
require 5.6;

