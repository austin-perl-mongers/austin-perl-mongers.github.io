
use test_lvalue;

use strict;

print valuable(), "\n";
valuable() = 2;
print valuable(), "\n";
