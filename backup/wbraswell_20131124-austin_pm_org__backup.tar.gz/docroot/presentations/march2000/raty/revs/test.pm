use strict;

my $val = 0;

sub valuable : lvalue { $val }

1;
