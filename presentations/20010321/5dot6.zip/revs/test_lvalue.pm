use strict;

my $val = 0;

sub valuable : lvalue {
  $DB::single = 1;
  $val
}

1;
